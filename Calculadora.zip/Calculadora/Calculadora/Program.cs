﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;


namespace Calculadora
{

    


    class Program
    {
        public static int Soma(int num1, int num2)
        {
            int resultado = num1 + num2;
            return resultado;
        }

        public static int Sub(int num1, int num2)
        {
            int resultado = num1 - num2;
            return resultado;
        }

        public static int Mult(int num1, int num2)
        {
            int resultado = num1 * num2;
            return resultado;
        }

        public static int Div(int num1, int num2)
        {
            int resultado = num1 / num2;
            return resultado;
        }

        public static double Pot(double num1, double num2)
        {
            double resultado = Math.Pow(num1, num2);
            return resultado;
        }

        public static double Raiz(double num1)
        {
            double resultado = Math.Sqrt(num1) ;
            return resultado;
        }

        static void Main(string[] args)
        {

            


            bool Ligar = true;
            double resultado;

            Console.WriteLine("Bem vinde, selecione a operação desejada ");
            while (Ligar)
            {

               
                Console.WriteLine("1 - Adição");
                Console.WriteLine("2 - Subtração");
                Console.WriteLine("3 - Multiplicação");
                Console.WriteLine("4 - Divisão");
                Console.WriteLine("5 - Potencialização");
                Console.WriteLine("6 - Raiz quadrada");
                Console.WriteLine("7 - Fechar");

                
                int op = int.Parse(Console.ReadLine());

                if (op <= 0)
                {
                    Console.WriteLine("Operação Invalida!");
                    Thread.Sleep(3500);
                    
                }else if (op > 7) {
                    Console.WriteLine("Operação Invalida!");
                    Thread.Sleep(3500);
                }else if(op == 6){

                    Console.WriteLine("Digite o numero a tirar raiz: ");
                    int num1 = int.Parse(Console.ReadLine());

                    resultado = Raiz(num1);
                    Console.WriteLine($"O resultado é {resultado}");
                    
                }else if (op == 7)
                {
                    Console.WriteLine("Obrigado, Volte sempre!");
                    Thread.Sleep(3500);
                    Ligar = false;
                }
                else
                {
                    
                    Console.WriteLine("Digite o primeiro numero: ");
                    int num1 = int.Parse(Console.ReadLine());

                    Console.WriteLine("Digite o Segundo numero: ");
                    int num2 = int.Parse(Console.ReadLine());

                    switch(op)
                    {
                        case 1:
                            {
                                resultado = Soma(num1, num2);
                                Console.WriteLine($"O resultado é {resultado}");
                                
                                break;
                                
                            }
                        case 2:
                            {
                                resultado = Sub(num1, num2);
                                Console.WriteLine($"O resultado é {resultado}");
                                break;
                            }
                        case 3:
                            {
                                resultado = Mult(num1, num2);
                                Console.WriteLine($"O resultado é {resultado}");
                                break;
                            }
                        case 4:
                            {
                                resultado = Div(num1, num2);
                                Console.WriteLine($"O resultado é {resultado}");
                                break;
                            }
                            case 5:
                            {
                                resultado = Pot(num1, num2);
                                Console.WriteLine($"O resultado é {resultado}");
                                break;
                            }
                            
                        
                    }

                }
                
                
            }
            
        }
    }
}
